package com.edatanalyser.dao;

import com.edatanalyser.mapping.EDAT_AnalyserConfigurationInterface;
import com.edatanalyser.services.EDAT_AnalyserUtils;
import com.matrixone.apps.framework.ui.UIUtil;
import java.io.File;
import java.io.IOException;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class EDAT_AnalyserConfigurationDAO extends EDAT_AnalyserUtils implements EDAT_AnalyserConfigurationInterface {
   private String fullMode = null;
   private String CADType = null;
   private String recoveryMode = null;
   private String releasedState = null;
   private String maturity = null;
   private String decodedPropertiesPath = null;
   private String cloudMigration = "OFF";
   private String lotStartDateTime = "LotStartDateTime";
   private String lotEndDateTime = "LotEndDateTime";
   private String baseDirectory = null;
   private String dashboard = "OFF";
   private boolean isGrtThan15x = false;
   List<String> lstImmediateTypes = new ArrayList();
   List<String> lstNonImmediateTypes = new ArrayList();

   public String getFullMode() {
      return this.fullMode;
   }

   public void setFullMode(String fullMode) {
      this.fullMode = fullMode;
   }

   public String getCADType() {
      return this.CADType;
   }

   public void setCADType(String cADType) {
      this.CADType = cADType;
   }

   public String getRecoveryMode() {
      return this.recoveryMode;
   }

   public void setRecoveryMode(String recoveryMode) {
      this.recoveryMode = recoveryMode;
   }

   public String getReleasedState() {
      return this.releasedState;
   }

   public void setReleasedState(String releasedState) {
      this.releasedState = releasedState;
   }

   public String getMaturity() {
      return this.maturity;
   }

   public void setMaturity(String maturity) {
      this.maturity = maturity;
   }

   public boolean isGrtThan15x() {
      return this.isGrtThan15x;
   }

   public void setGrtThan15x(String isGrtThan15x) {
      if (UIUtil.isNotNullAndNotEmpty(isGrtThan15x) && "True".equalsIgnoreCase(isGrtThan15x)) {
         this.isGrtThan15x = true;
      }

   }

   public String getDecodedPropertiesPath() {
      return this.decodedPropertiesPath;
   }

   public void setDecodedPropertiesPath() throws IOException {
      String propertiesPath = (new File((new File(".")).getAbsolutePath())).getParentFile().getParentFile().getCanonicalPath();
      this.decodedPropertiesPath = URLDecoder.decode(propertiesPath, "UTF-8");
   }

   public String getCloudMigration() {
      return this.cloudMigration;
   }

   public void setCloudMigration(String cloudMigration) {
      if (UIUtil.isNotNullAndNotEmpty(cloudMigration) && "ON".equals(cloudMigration)) {
         this.cloudMigration = "ON";
      }

   }

   public List<String> getLstImmediateTypes() {
      return this.lstImmediateTypes;
   }

   public void setLstImmediateTypes() {
      this.lstImmediateTypes.add("CATPart");
      this.lstImmediateTypes.add("SW Component Family");
      this.lstImmediateTypes.add("CATDrawing");
      this.lstImmediateTypes.add("SW Drawing");
      this.lstImmediateTypes.add("CATMaterial");
      this.lstImmediateTypes.add("CATIA V4 Model");
      this.lstImmediateTypes.add("CATIA Design Table");
      this.lstImmediateTypes.add("CATIA CGR");
      this.lstImmediateTypes.add("CATIA Catalog");
      this.lstImmediateTypes.add("CATAnalysis");
      this.lstImmediateTypes.add("CATAnalysisComputations");
      this.lstImmediateTypes.add("CATAnalysisResults");
      this.lstImmediateTypes.add("CATShape");
      this.lstImmediateTypes.add("CATProcess");
      this.lstImmediateTypes.add("Document");
      this.lstImmediateTypes.add("INV Component");
      this.lstImmediateTypes.add("INV Part Factory");
      this.lstImmediateTypes.add("INV Drawing");
      this.lstImmediateTypes.add("INV Presentation");
      this.lstImmediateTypes.add("UG Drawing");
      this.lstImmediateTypes.add("UG Model");
   }

   public List<String> getLstNonImmediateTypes() {
      return this.lstNonImmediateTypes;
   }

   public void setLstNonImmediateTypes() {
      this.lstNonImmediateTypes.add("CATProduct");
      this.lstNonImmediateTypes.add("SW Assembly Family");
      this.lstNonImmediateTypes.add("INV Assembly");
      this.lstNonImmediateTypes.add("INV Assembly Factory");
      this.lstNonImmediateTypes.add("UG Assembly");
      this.lstNonImmediateTypes.add("CATIA Embedded Component");
   }

   public String getLotStartDateTime() {
      return this.lotStartDateTime;
   }

   public void setLotStartDateTime(String lotStartDateTime) {
      this.lotStartDateTime = lotStartDateTime;
   }

   public String getLotEndDateTime() {
      return this.lotEndDateTime;
   }

   public void setLotEndDateTime(String lotEndDateTime) {
      this.lotEndDateTime = lotEndDateTime;
   }

   public String getBaseDirectory() {
      return this.baseDirectory;
   }

   public void setBaseDirectory(String baseDirectory) {
      Date now = new Date();
      SimpleDateFormat dateFormat = new SimpleDateFormat("ddMMMYY_HH:mm:ss:SSS");
      String time = dateFormat.format(now).replaceAll(":", "_").replaceAll(" ", "_");
      this.baseDirectory = baseDirectory + "/" + time;
   }

   public void validateDirectory(String directory) throws IOException {
      createDirectory(directory);
   }

   public String getDashboard() {
      return this.dashboard;
   }

   public void setDashboard(String dashboard) {
      if (UIUtil.isNotNullAndNotEmpty(dashboard) && "ON".equals(dashboard)) {
         this.dashboard = "ON";
      }

   }
}
