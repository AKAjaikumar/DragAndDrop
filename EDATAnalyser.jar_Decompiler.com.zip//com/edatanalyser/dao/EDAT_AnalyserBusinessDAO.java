package com.edatanalyser.dao;

import com.edatanalyser.mapping.EDAT_AnalyserBusinessInterface;
import com.edatanalyser.mapping.EDAT_AnalyserConfigurationInterface;
import com.edatanalyser.services.EDAT_AnalyserUtils;
import com.edatanalyser.services.EDAT_DB_Analyser;
import com.edatxflowlogger.XFlowLogger;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.StringUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import matrix.db.Context;
import matrix.util.StringList;

public class EDAT_AnalyserBusinessDAO extends EDAT_AnalyserUtils implements EDAT_AnalyserBusinessInterface {
   private Properties properties = EDAT_AnalyserUtils.getProperties("analyser.properties", (XFlowLogger)null);
   private String filenameLenGT100Char;
   private int fileNameLength;
   private String havingSpaceFilesNames;
   private String cadBusSelect;
   private String invalidChar;
   private List<Character> invalidCharLst;
   private EDAT_AnalyserConfigurationInterface configObj;

   public EDAT_AnalyserBusinessDAO() {
      this.filenameLenGT100Char = this.properties.getProperty("EDATAnalyser.FileNameGT100Char");
      this.fileNameLength = Integer.parseInt(this.properties.getProperty("EDATAnalyser.FileNameLength"));
      this.havingSpaceFilesNames = this.properties.getProperty("EDATAnalyser.SpaceInFileNames");
      this.cadBusSelect = this.properties.getProperty("EDATAnalyser.CAD.ObjectSelects");
      this.invalidChar = this.properties.getProperty("EDATAnalyser.InvalidCharc");
      this.invalidCharLst = this.convertStringToCharList(this.invalidChar);
      this.configObj = new EDAT_AnalyserConfigurationDAO();
   }

   public String getRootQuery() {
      String command = "temp query bus $1 $2 $3  where $4  select $5 $6 $7 $8 $9 dump $10 output $11";
      return command;
   }

   public String getLOTDateTimeWhereClause(EDAT_AnalyserConfigurationInterface obj, XFlowLogger xMLLogger) {
      String tempWhere = "";
      String lotStartDate = obj.getLotStartDateTime();
      String lotEndDate = obj.getLotEndDateTime();

      try {
         xMLLogger.AddNodewithTextValue("LotStartDateTime", lotStartDate);
         xMLLogger.AddNodewithTextValue("LotEndDateTime", lotEndDate);
         xMLLogger.SaveXFlowXML();
         tempWhere = this.validateDates(lotStartDate, lotEndDate, xMLLogger, tempWhere);
      } catch (Exception var7) {
         EDAT_DB_Analyser.printTrace("EDAT_DB_Analyser : getDateWhere : Exception --->>>>> : " + var7.getMessage());
         System.out.println("EDAT_DB_Analyser : Exception While getting lot start and end date condition ----->>  " + var7.getMessage());
      }

      EDAT_DB_Analyser.printTrace("EDAT_AnalyserBusinessDAO : getDateWhere : tempWhere --->>>>> : " + tempWhere);
      return tempWhere;
   }

   private String validateDates(String lotStartDate, String lotEndDate, XFlowLogger xMLLogger, String tempWhere) throws ParseException {
      Date dtStartLot = null;
      Date dtEndLot = null;
      if (UIUtil.isNotNullAndNotEmpty(lotStartDate)) {
         dtStartLot = (new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a")).parse(lotStartDate);
         tempWhere = "originated >= '" + lotStartDate + "' && ";
      }

      if (UIUtil.isNotNullAndNotEmpty(lotEndDate)) {
         dtEndLot = (new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a")).parse(lotEndDate);
         tempWhere = tempWhere + " originated <= '" + lotEndDate + "' && ";
      }

      if (dtStartLot != null && dtEndLot != null) {
         if (dtStartLot.after(dtEndLot)) {
            System.out.println("START DATE CANNOT BE GREATER THAN END DATE");
            loggedXflowGlobalStatus(xMLLogger, "KO", "start date cannot be greater than end date");
            return "invalid";
         }

         if (dtStartLot.equals(dtEndLot)) {
            System.out.println("START DATE EQUAL TO END DATE");
            loggedXflowGlobalStatus(xMLLogger, "KO", "start date equal to end date");
            return "invalid";
         }
      }

      EDAT_DB_Analyser.printTrace("EDAT_AnalyserBusinessDAO : validateDates : tempWhere --->>>>> : " + tempWhere);
      return tempWhere;
   }

   public StringBuffer getCadBasedWhereClause(String type, String cadType, boolean isGrt15x, String state) {
      new StringBuffer();
      String strCurrent = "islast == true || (current == " + state.replaceAll(",", " && current == ") + ")";
      StringBuffer tempWhere;
      if (isGrt15x) {
         tempWhere = this.getCadBasedWCFGT15x(cadType, strCurrent, type);
      } else {
         tempWhere = this.getCadBasedWCFLT15x(cadType, state);
      }

      EDAT_DB_Analyser.printTrace("EDAT_DB_Analyser : getCadBasedWhereClause : tempWhere :----->>>> : " + tempWhere);
      return tempWhere;
   }

   private StringBuffer getCadBasedWCFGT15x(String cadType, String releasedState, String type) {
      StringBuffer tempWhere = new StringBuffer();
      if ("NONCAD".equalsIgnoreCase(cadType)) {
         tempWhere.append("policy == 'Document Release'");
      } else if ("INVENTOR".equalsIgnoreCase(cadType)) {
         tempWhere.append("policy == 'Design TEAM Definition' && ").append("(type == 'INV Component' || type=='INV Drawing' || ").append("to[CAD SubComponent]== False) && (type != 'INV iPart') && (type != 'INV iAssembly') && ").append("(" + releasedState + ")");
      } else if ("SOLIDWORKS".equalsIgnoreCase(cadType)) {
         tempWhere.append("policy == 'Design TEAM Definition' && ").append("(type == 'SW Drawing' || type == 'SW Component Family' ||").append("from[Instance Of].to.to[CAD SubComponent]== False) && ").append("(" + releasedState + ")");
      } else if ("CATIA".equalsIgnoreCase(cadType)) {
         if (!type.equalsIgnoreCase("CATIA Catalog") && !type.equalsIgnoreCase("CATMaterial")) {
            tempWhere.append("policy == 'Design TEAM Definition' && ").append("(type == 'CATPart'  || type == 'CATDrawing' || ").append("from[Active Version].to.to[CAD SubComponent]== False) && ").append("(" + releasedState + ")");
         } else {
            tempWhere.append("(from[Active Version].to.to[CAD SubComponent]== False || (type == 'CATPart' && policy == 'Design TEAM Resource')) && ").append("(" + releasedState + ")");
         }
      } else if ("NX".equalsIgnoreCase(cadType)) {
         tempWhere.append("policy == 'Design TEAM Definition' && ").append("(type == 'UG Model'  || type == 'UG Drawing' || ").append("to[CAD SubComponent]==False) && ").append("(" + releasedState + ")").append("&& format.file.capturedfile!=null");
      }

      return tempWhere;
   }

   private StringBuffer getCadBasedWCFLT15x(String cadType, String state) {
      StringBuffer tempWhere = new StringBuffer();
      if ("NONCAD".equalsIgnoreCase(cadType)) {
         tempWhere.append("policy == 'Document'");
      } else if ("SOLIDWORKS".equalsIgnoreCase(cadType)) {
         tempWhere.append(" ((current != '" + state + "' && from[Active Version].to.from[Instance Of].to.to[CAD SubComponent]== False) || ").append("(current == '" + state + "' && to[CAD SubComponent]== False)) ").append("|| (type == 'SW Drawing' || type == 'SW Component Family')");
      } else if ("CATIA".equalsIgnoreCase(cadType)) {
         tempWhere.append("((type == 'CATPart'  || type == 'CATDrawing') || ").append("(current != '" + state + "' && from[Active Version].to.to[CAD SubComponent]== False) || ").append("(current == '" + state + "' && to[CAD SubComponent]== False)) ");
      }

      EDAT_DB_Analyser.printTrace("EDAT_DB_Analyser : getCadBasedWCFLT15x : tempWhere :----->>>> : " + tempWhere);
      return tempWhere;
   }

   public void fetchServerDataBased(Context context, String type, String command, String whereClause, String baseDir, boolean decVersion, String cadType) throws FrameworkException {
      String outPutPathFirstRev = baseDir + "/" + type + "_FirstRev.txt";
      String fileName = "";
      EDAT_DB_Analyser.printTrace("EDAT_DB_Analyser : fetchServerDataBased : cadType :----->>>> : " + cadType);
      EDAT_DB_Analyser.printTrace("EDAT_DB_Analyser : fetchServerDataBased : whereClause :----->>>> : " + whereClause);
      EDAT_DB_Analyser.printTrace("EDAT_DB_Analyser : fetchServerDataBased : type :----->>>> : " + type);
      if (!decVersion && !"NONCAD".equalsIgnoreCase(cadType)) {
         fileName = "from[Active Version].to.format.file.name";
      } else {
         fileName = "format.file.name";
      }

      EDAT_DB_Analyser.printTrace("EDAT_DB_Analyser : fetchServerDataBased : fileName :----->>>> : " + fileName);
      MqlUtil.mqlCommand(context, command, new String[]{type, "*", "*", whereClause + " && revindex==0", "modified", "current", "originated", "id", fileName, "|", outPutPathFirstRev});
      String outPutPathRestRev = baseDir + "/" + type + "_RestRev.txt";
      MqlUtil.mqlCommand(context, command, new String[]{type, "*", "*", whereClause + " && revindex!=0", "modified", "current", "originated", "id", fileName, "|", outPutPathRestRev});
   }

   public boolean cleanDataCheck(String type, String name, String rev, String fileName, String busId) {
      String tnr = type + "," + name + "," + rev + "," + busId + "\n";
      String[] fileNamesArray = fileName.split("\\|");
      String[] fname = null;
      if (lstSkipObjects.size() > 0 && lstSkipObjects.contains(tnr)) {
         System.out.println("skipped : " + tnr);
         EDAT_DB_Analyser.printTrace("EDAT_DB_Analyser : analyser : skipped object str:----->>>> : " + tnr);
         return false;
      } else if (this.checkNameContainSpace(name)) {
         lstHavingSpaceFilesNames.add(tnr + "\n");
         return false;
      } else if (this.checkNameInvalid(name)) {
         lstInvalidNames.add(tnr + "\n");
         return false;
      } else if (!type.equalsIgnoreCase("Document") && fileNamesArray.length > 1) {
         lstHavingMultipleFilesAttached.add(tnr + "\n");
         return false;
      } else {
         String[] var12 = fileNamesArray;
         int var11 = fileNamesArray.length;

         for(int var10 = 0; var10 < var11; ++var10) {
            String singleFileName = var12[var10];
            if (this.checkFileMissing(singleFileName)) {
               if (!lstMissingFilesNames.contains(tnr + "\n")) {
                  lstMissingFilesNames.add(tnr + "\n");
               }

               return false;
            }

            if (singleFileName.length() > 0) {
               fname = singleFileName.split("\\.(?=[^\\.]+$)");
               if (this.checkFileNameLengthGT100Char(fname[0]) && "True".equalsIgnoreCase(this.filenameLenGT100Char)) {
                  lstFilenameLenGT100Char.add(tnr + "\n");
                  return false;
               }

               if (this.checkNameContainSpace(fname[0]) && "True".equalsIgnoreCase(this.havingSpaceFilesNames)) {
                  lstHavingSpaceFilesNames.add(tnr + "\n");
                  return false;
               }
            }
         }

         EDAT_DB_Analyser.printTrace("EDAT_DB_Analyser : Data is clean for migration : for type: " + type + " name: " + name + " rev: " + rev);
         return true;
      }
   }

   private boolean checkNameContainSpace(String objName) {
      return Character.isWhitespace(objName.charAt(0)) || Character.isWhitespace(objName.charAt(objName.length() - 1));
   }

   private boolean checkFileNameLengthGT100Char(String filename) {
      return filename.length() > this.fileNameLength;
   }

   private boolean checkNameInvalid(String strName) {
      if (this.invalidCharLst != null && this.invalidCharLst.size() > 0) {
         List<Character> nameList = new ArrayList();
         char[] chName = strName.toCharArray();
         char[] var7 = chName;
         int var6 = chName.length;

         for(int var5 = 0; var5 < var6; ++var5) {
            char c = var7[var5];
            nameList.add(c);
            if (this.invalidCharLst.contains(c)) {
               return true;
            }
         }
      }

      return false;
   }

   private boolean checkFileMissing(String filename) {
      if (UIUtil.isNotNullAndNotEmpty(filename)) {
         return false;
      } else {
         return UIUtil.isNullOrEmpty(filename);
      }
   }

   private List<Character> convertStringToCharList(String invalidChar) {
      List<Character> chars = new ArrayList();
      if (UIUtil.isNotNullAndNotEmpty(invalidChar)) {
         char[] var6;
         int var5 = (var6 = invalidChar.toCharArray()).length;

         for(int var4 = 0; var4 < var5; ++var4) {
            char ch = var6[var4];
            chars.add(ch);
         }
      }

      return chars;
   }

   public MapList getRootObjectDetails(Context context, StringList busIds, String type) {
      MapList mlCadObj = null;
      EDAT_DB_Analyser.printTrace("EDAT_DB_Analyser : getRootObjectDetails : cadBusSelect --->>>>> : " + this.cadBusSelect);
      StringList slBusList = StringUtil.split(this.cadBusSelect, ",");
      EDAT_DB_Analyser.printTrace("EDAT_DB_Analyser : getRootObjectDetails : slBusList --->>>>> : " + slBusList + " , type -->" + type);
      this.configObj.setLstNonImmediateTypes();
      if (this.configObj.getLstNonImmediateTypes().contains(type)) {
         if ("SW Assembly Family".equalsIgnoreCase(type)) {
            slBusList.add("from[Instance Of].to.from[CAD SubComponent].to.to[Instance Of].from[SW Assembly Family].id");
            slBusList.add("from[Instance Of].to.from[CAD SubComponent].to.to[Instance Of].from.type");
            slBusList.add("from[Active Version].to.from[Instance Of].to.from[CAD SubComponent].to.to[Instance Of].from.to[Active Version].from[SW Assembly Family].id");
            slBusList.add("from[Active Version].to.from[Instance Of].to.from[CAD SubComponent].to.to[Instance Of].from.to[Active Version].from.type");
            slBusList.add("from[Active Instance].to.from[CAD SubComponent].to.from[SW External Reference].to.id");
            slBusList.add("from[Active Instance].to.id");
            slBusList.add("from[Active Version].to.from[Active Instance].to.from[CAD SubComponent].to.from[SW External Reference].to.id");
            slBusList.add("from[Active Version].to.from[Active Instance].to.id");
         }

         slBusList.add("from[Active Version].to.from[CAD SubComponent].to.from[VersionOf].to[CATProduct].id");
         slBusList.add("from[Active Version].to.from[CAD SubComponent].to.from[VersionOf].to.type");
         slBusList.add("from[CAD SubComponent].to.type");
         slBusList.add("from[CAD SubComponent].to[" + type + "].id");
         slBusList.add("from[CAD SubComponent].to[CATProduct].id");
         slBusList.add("from[CAD SubComponent].to[CATIA Embedded Component].id");
         slBusList.add("from[Active Version].to.from[CAD SubComponent].to.from[VersionOf].to[CATIA Embedded Component].id");
      }

      EDAT_DB_Analyser.printTrace("EDAT_DB_Analyser : getRootObjectDetails : slBusList --->>>>> : " + slBusList);

      try {
         String[] busIdsArray = (String[])busIds.toArray(new String[busIds.size()]);
         EDAT_DB_Analyser.printTrace("EDAT_DB_Analyser : getRootObjectDetails : busIdsArray --->>>>> : " + Arrays.toString(busIdsArray));
         mlCadObj = DomainObject.getInfo(context, busIdsArray, slBusList);
      } catch (Exception var7) {
         EDAT_DB_Analyser.printTrace("EDAT_DB_Analyser : getRootObjectDetails method Failed unable to retrieve data from the BOS" + var7.getMessage());
      }

      EDAT_DB_Analyser.printTrace("EDAT_DB_Analyser : getRootObjectDetails:  mlCadObj.size ------>>>> " + mlCadObj.size());
      EDAT_DB_Analyser.printTrace("EDAT_DB_Analyser : getRootObjectDetails:  mlCadObj ------>>>> " + mlCadObj);
      return mlCadObj;
   }
}
