package com.edatanalyser.services;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

public class EDAT_Comparators implements Comparator<String> {
   private List<Comparator<String>> listComparators;

   @SafeVarargs
   public EDAT_Comparators(Comparator<String>... comparators) {
      this.listComparators = Arrays.asList(comparators);
   }

   public int compare(String rs1, String rs2) {
      Iterator var4 = this.listComparators.iterator();

      while(var4.hasNext()) {
         Comparator<String> comparator = (Comparator)var4.next();
         int result = comparator.compare(rs1, rs2);
         if (result != 0) {
            return result;
         }
      }

      return 0;
   }
}
