package com.edatanalyser.services;

import com.matrixone.apps.framework.ui.UIUtil;
import java.io.File;
import java.util.Comparator;

public class EDAT_NameComparator extends EDAT_AnalyserUtils implements Comparator<String> {
   public int compare(String o1, String o2) {
      if (UIUtil.isNotNullAndNotEmpty(o1) && UIUtil.isNotNullAndNotEmpty(o2)) {
         int n1 = this.extractNumber(o1);
         int n2 = this.extractNumber(o2);
         if (n1 == n2) {
            return 0;
         } else {
            return n1 < n2 ? 1 : -1;
         }
      } else {
         return 0;
      }
   }

   private int extractNumber(String strname) {
      int i = 0;
      File f = new File(strname);
      String name = f.getName();
      if (name.equals("Analysis.txt")) {
         return -1;
      } else {
         if (name.contains("_Analysis")) {
            name = name.substring(0, name.lastIndexOf("_Analysis"));

            try {
               int s = name.lastIndexOf("_") + 1;
               int e = name.length();
               String number = name.substring(s, e);
               i = Integer.parseInt(number);
            } catch (Exception var8) {
               i = -1;
            }
         }

         return i;
      }
   }
}
