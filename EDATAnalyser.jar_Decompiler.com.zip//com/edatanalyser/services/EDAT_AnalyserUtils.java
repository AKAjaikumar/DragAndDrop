package com.edatanalyser.services;

import com.edatxflowlogger.XFlowLogger;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Properties;

public class EDAT_AnalyserUtils {
   public static final String CADTYPE = "CADType";
   public static final String CADTYPE_SOLIDWORKS = "SOLIDWORKS";
   public static final String CADTYPE_CATIA = "CATIA";
   public static final String CADTYPE_NONCAD = "NONCAD";
   public static final String CADTYPE_INVENTOR = "INVENTOR";
   public static final String DOCUMENT_POLICY = "Document Release";
   public static final String DTD_POLICY = "Design TEAM Definition";
   public static final String TYPE_CATIA_DRAWING = "CATDrawing";
   public static final String TYPE_CAT_PART = "CATPart";
   public static final String TYPE_CATIA_DESIGN_TABLE = "CATIA Design Table";
   public static final String TYPE_CATMATERIAL = "CATMaterial";
   public static final String TYPE_CATANALYSIS = "CATAnalysis";
   public static final String TYPE_CATANALYSISRESULTS = "CATAnalysisResults";
   public static final String TYPE_CATANALYSISCOMPUTATIONS = "CATAnalysisComputations";
   public static final String TYPE_CATPROCESS = "CATProcess";
   public static final String TYPE_CATIA_CATALOG = "CATIA Catalog";
   public static final String TYPE_CATSHAPE = "CATShape";
   public static final String TYPE_CATIA_V4_MODEL = "CATIA V4 Model";
   public static final String TYPE_CATIA_CGR = "CATIA CGR";
   public static final String TYPE_CAT_PRODUCT = "CATProduct";
   public static final String TYPE_SW_ASSEMBLY_FAMILY = "SW Assembly Family";
   public static final String TYPE_SW_DRAWING = "SW Drawing";
   public static final String TYPE_SW_COMPONENT_FAMILY = "SW Component Family";
   public static final String SWDRAWING = "SWDrawing";
   public static final String SWASSEMBLYFAMILY = "SWAssemblyFamily";
   public static final String TYPE_INV_COMPONENT = "INV Component";
   public static final String TYPE_INV_PART_FACTORY = "INV Part Factory";
   public static final String TYPE_INV_DRAWING = "INV Drawing";
   public static final String TYPE_INV_PRESENTATION = "INV Presentation";
   public static final String TYPE_INV_ASSEMBLY = "INV Assembly";
   public static final String TYPE_INV_ASSEMBLY_FACTORY = "INV Assembly Factory";
   public static final String TYPE_DOCUMENT = "Document";
   public static final String SW_PART = "SWPart";
   public static final String CADTYPE_NX = "NX";
   public static final String TYPE_NX_UGMODEL = "UG Model";
   public static final String TYPE_NX_UGASSEMBLY = "UG Assembly";
   public static final String TYPE_NX_UGDRAWING = "UG Drawing";
   public static final String TYPE_CATIA_EMBEDDED_COMPONENT = "CATIA Embedded Component";
   public static final String EXPORT_TXT = "Export.txt";
   public static final String ANALYSER_PROPERTIES = "analyser.properties";
   public static final String DOCINPUTTYPE_TXT = "DocumentInputType.txt";
   public static final String REST_REV_TXT = "_RestRev.txt";
   public static final String FIRST_REV_TXT = "_FirstRev.txt";
   public static final String RECVOERYFILENAME = "Recovery.xml";
   public static final String MISSING_FILE_NAMES_TXT = "EmptyFileName.txt";
   public static final String INVALID_FILE_NAMES_TXT = "InvalidFileName.txt";
   public static final String HAVING_SPACE_IN_NAMES_TXT = "HavingSpaceInNamesOrFileName.txt";
   public static final String HAVING_MORE_THAN_100_CHAR_IN_FILENAMES_TXT = "HavingNamesOrFileNameMoreThan100Char.txt";
   public static final String HAVING_MORE_THAN_ONE_FILE_TXT = "CadObjectHavnigMoreThanOneFile.txt";
   public static final String ANALYSIS_TXT = "Analysis.txt";
   public static final String ROOTSFOR_GT15X_TXT = "RootsforGT15x.txt";
   public static final String ALL_ROOTSFOR_GT15X_TXT = "AllRootsforGT15x.txt";
   public static final String ROOTSFOR_LT15X_TXT = "RootsforLT15x.txt";
   public static final String ALL_ROOTSFOR_LT15X_TXT = "AllRootsforLT15x.txt";
   public static final String CONFIG_XML = "config.xml";
   public static final String DBCONFIG_XML = "dbConfig.xml";
   public static final String CYCLIC_DATA_TXT = "CyclicData.txt";
   public static final String EXPORT_TXT_PATH = "Export_Paths_ ";
   public static final String FIRST_REV = "FirstRev";
   public static final String REST_REV = "RestRev";
   public static final String CONFIG = "config";
   public static final String JMS_EVENT_READ_LOCATION = "BaseDirectory";
   public static final String ANALYSER_OUTPUT = "BaseDirectory";
   public static final String RECOVERY_MODE = "RecoveryMode";
   public static final String CONFIG_FILE_NAME = "ConfigFileName";
   public static final String RELEASED_STATE = "ReleasedState";
   public static final String RECOVERY = "Recovery";
   public static final String MAX_ROOTS_IN_ONE_FILE = "MaxRootsInOneFile";
   public static final String ACTIVE_MQ_PATH = "ActiveMQPath";
   public static final String DASHBOARD = "Dashboard";
   public static final String LOG_PATH = "LogPath";
   public static final String FULL_MIGRATION_SCOPE = "FullMigrationScope";
   public static final String EXPORT_QUEUE_NAME = "ExportQueueName";
   public static final String ANALYZER = "Analyzer";
   public static final String ISVERSIONGREATERTHAN15X = "IsVersionGreaterThan15x";
   public static final String DOCINPUTTYPE = "Analysing Type";
   public static final String MD5 = "MD5";
   public static final String STRING_SEP = "_";
   public static final String ON = "ON";
   public static final String OFF = "OFF";
   public static final String UNDERSCORE = "_";
   public static final String COLON = ":";
   public static final String PATH_SEPRATOR = "\\";
   public static final String NEWLINE = "\n";
   public static final String SLASH = "/";
   public static final String TRUE = "True";
   public static final String SORT_DESCENDING = "descending";
   public static final String DOT = ".";
   public static final String FALSE = "False";
   public static final String UTC_CONSTANT = "UTC";
   public static final String COMMA = ",";
   public static final String SEMICOLON = ";";
   public static final String VALUE_ZERO = "0";
   public static final String WHITE_SPACE = " ";
   public static final String UTF_8 = "UTF-8";
   public static final String OK = "OK";
   public static final String KO = "KO";
   public static final String CONSTANT_UUID = "UUID";
   public static final String SORT_ASCENDING = "ascending";
   public static final String FormatSeparator = "|";
   public static final String EXTRACT_FOLDER_DATEFORMAT = "ddMMMYY_HH:mm:ss:SSS";
   public static final String UTC_DATE_FORMAT = "MM/dd/yyyy hh:mm:ss a";
   public static final String YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";
   public static final String DURATION = "Duration";
   public static final String CONSTANT_HOUR = " hr ";
   public static final String CONSTANT_MIN = " min ";
   public static final String CONSTANT_SEC = " sec ";
   public static final String CONSTANT_MSEC = " msec ";
   public static final String END_DATE_TIME = "EndDateTime";
   public static final String START_DATE_TIME = "StartDateTime";
   public static final String LOT_START_DATE_TIME = "LotStartDateTime";
   public static final String LOT_END_DATE_TIME = "LotEndDateTime";
   public static final String DD_MMM_YYYY_HH_MM_SS_SSS = "dd MMM yyyy HH:mm:ss:SSS Z";
   public static final String HH_MM_SS = "HH:mm:ss:SSS";
   public static final String FROM_ACTIVE_VERSION_TO_FROM_INSTANCE_OF_TO_FROM_CAD_SUB_COMPONENT_TO_TO_INSTANCE_OF_FROM_TO_ACTIVE_VERSION_FROM_NAME = "from[Active Version].to.from[Instance Of].to.from[CAD SubComponent].to.to[Instance Of].from.to[Active Version].from.name";
   public static final String FROM_ACTIVE_VERSION_TO_FROM_INSTANCE_OF_TO_FROM_CAD_SUB_COMPONENT_TO_TO_INSTANCE_OF_FROM_TO_ACTIVE_VERSION_FROM_TYPE = "from[Active Version].to.from[Instance Of].to.from[CAD SubComponent].to.to[Instance Of].from.to[Active Version].from.type";
   public static final String FROM_ACTIVE_VERSION_TO_FROM_INSTANCE_OF_TO_FROM_CAD_SUB_COMPONENT_TO_TO_INSTANCE_OF_FROM_TO_ACTIVE_VERSION_FROM_ID = "from[Active Version].to.from[Instance Of].to.from[CAD SubComponent].to.to[Instance Of].from.to[Active Version].from[SW Assembly Family].id";
   public static final String FROM_INSTANCE_OF_TO_FROM_CAD_SUB_COMPONENT_TO_TO_INSTANCE_OF_FROM_TYPE = "from[Instance Of].to.from[CAD SubComponent].to.to[Instance Of].from.type";
   public static final String FROM_ACTIVE_INSTANCE_TO_FROM_CAD_SUBCOMPONENT_TO_FROM_SW_EXTERNAL_REFERENCE_TO_ID = "from[Active Instance].to.from[CAD SubComponent].to.from[SW External Reference].to.id";
   public static final String FROM_ACTIVE_INSTANCE_TO_ID = "from[Active Instance].to.id";
   public static final String FROM_ACTIVE_VERSION_TO_FROM_ACTIVE_INSTANCE_TO_ID = "from[Active Version].to.from[Active Instance].to.id";
   public static final String FROM_ACTIVE_VERSION_TO_FROM_ACTIVE_INSTANCE_TO_FROM_CAD_SUBCOMPONENT_TO_FROM_SW_EXTERNAL_REFERENCE_TO_ID = "from[Active Version].to.from[Active Instance].to.from[CAD SubComponent].to.from[SW External Reference].to.id";
   public static final String FROM_INSTANCE_OF_TO_FROM_CAD_SUB_COMPONENT_TO_TO_INSTANCE_OF_FROM_ID = "from[Instance Of].to.from[CAD SubComponent].to.to[Instance Of].from[SW Assembly Family].id";
   public static final String TO_ASSOCIATED_DRAWING_FROM_TO_INSTANCE_OF_FROM_NAME = "to[Associated Drawing].from.to[Instance Of].from.name";
   public static final String FROM_ACTIVE_VERSION_TO_TO_ASSOCIATED_DRAWING_FROM_FROM_VERSION_OF_TO_REVISION = "from[Active Version].to.to[Associated Drawing].from.from[VersionOf].to.revision";
   public static final String FROM_ACTIVE_VERSION_TO_TO_ASSOCIATED_DRAWING_FROM_FROM_VERSION_OF_TO_NAME2 = "from[Active Version].to.to[Associated Drawing].from.from[VersionOf].to.name";
   public static final String FROM_ACTIVE_VERSION_TO_TO_ASSOCIATED_DRAWING_FROM_FROM_VERSION_OF_TO_TYPE = "from[Active Version].to.to[Associated Drawing].from.from[VersionOf].to.type";
   public static final String TO_ASSOCIATED_DRAWING_FROM_REVISION = "to[Associated Drawing].from.revision";
   public static final String TO_ASSOCIATED_DRAWING_FROM_NAME2 = "to[Associated Drawing].from.name";
   public static final String TO_ASSOCIATED_DRAWING_FROM_TYPE = "to[Associated Drawing].from.type";
   public static final String TO_ASSOCIATED_DRAWING_FROM_TO_INSTANCE_OF_FROM_REVISION = "to[Associated Drawing].from.to[Instance Of].from.revision";
   public static final String TO_ASSOCIATED_DRAWING_FROM_TO_INSTANCE_OF_FROM_TYPE = "to[Associated Drawing].from.to[Instance Of].from.type";
   public static final String FROM_ACTIVE_VERSION_TO_FORMAT_FILE_FORMAT = "from[Active Version].to.format.file.format";
   public static final String FROM_ACTIVE_VERSION_TO_FORMAT_FILE_NAME = "from[Active Version].to.format.file.name";
   public static final String FORMAT_FILE_FORMAT = "format.file.format";
   public static final String FORMAT_FILE_NAME = "format.file.name";
   public static final String FORMAT_HASFILE = "format.hasfile";
   public static final String FROM_ACTIVE_VERSION_TO_FORMAT_HASFILE = "from[Active Version].to.format.hasfile";
   public static final String TO_ASSOCIATED_DRAWING_FROM_TO_INSTANCE_OF_FROM_NAME2 = "to[Associated Drawing].from.to[Instance Of].from.name";
   public static final String SQL_DRIVER = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
   public static final String ORACLE_DRIVER = "oracle.jdbc.OracleDriver";
   public static final String PASSWORD = "Password";
   public static final String CONNECTION_STRING = "ConnectionString";
   public static final String DBTYPE_LOG = "DB Type";
   public static final String DB_TYPE = "DBType";
   public static final String DBTYPE_ORACLE = "Oracle";
   public static final String DBTYPE_MSSQL = "MSSQL";
   public static final String ANALYSIS = "Analysis";
   public static final String DATA_SOURCE = "Data Source";
   public static final String INITIAL_CATALOG = "Initial Catalog";
   public static final String HOST = "HOST";
   public static final String PORT = "PORT";
   public static final String SERVICE_NAME = "SERVICE_NAME";
   public static final String USERID = "User ID";
   public static final String MODIFICATION_DATE = "MODIFICATION_DATE";
   public static final String BUS_ID = "BUS_ID";
   public static final String STATUS = "STATUS";
   public static final String IMPORT_DATA = "IMPORT_DATA";
   public static final String MATURITY = "Maturity";
   public static final String CLOUDMIGRATION = "CloudMigration";
   public static final String FAILURECASE = "FailureCase.txt";
   public static final String PATHLIST = "_pathlist.txt";
   public static final String SKIP_OBJECTS_TXT = "SkipObjects.txt";
   public static final String SKIP_OBJECTS = "SkipObjects";
   public static final String FileNameGT100Char = "EDATAnalyser.FileNameGT100Char";
   public static final String SpaceInFileNames = "EDATAnalyser.SpaceInFileNames";
   public static final String CADBusSelect = "EDATAnalyser.CAD.ObjectSelects";
   public static final String InvalidCharc = "EDATAnalyser.InvalidCharc";
   public static final String FileNameLength = "EDATAnalyser.FileNameLength";
   public static final String FROM_ACTIVE_VERSION_TO_FROM_CAD_SUBCOMPONENT_TO_FROM_VERSIONOF_TO_ID = "from[Active Version].to.from[CAD SubComponent].to.from[VersionOf].to[CATProduct].id";
   public static final String FROM_ACTIVE_VERSION_TO_FROM_CAD_SUBCOMPONENT_TO_FROM_VERSIONOF_TO_CATIAEMBEDDEDCOMPONENT_ID = "from[Active Version].to.from[CAD SubComponent].to.from[VersionOf].to[CATIA Embedded Component].id";
   public static final String FROM_ACTIVE_VERSION_TO_FROM_CAD_SUBCOMPONENT_TO_FROM_VERSIONOF_TO_TYPE = "from[Active Version].to.from[CAD SubComponent].to.from[VersionOf].to.type";
   public static final String FROM_CAD_SUBCOMPONENT_TO_ID = "from[CAD SubComponent].to.id";
   public static final String FROM_CAD_SUBCOMPONENT_TO_TYPE = "from[CAD SubComponent].to.type";
   public static final String FROM_CAD_SUBCOMPONENT_TO_CATIA_EMBEDDED_COMPONENT_ID = "from[CAD SubComponent].to[CATIA Embedded Component].id";
   public static final String FROM_CAD_SUBCOMPONENT_TO_CATPRODUCT_ID = "from[CAD SubComponent].to[CATProduct].id";

   public static String getUUID(String str) throws NoSuchAlgorithmException {
      return convertToHexa32(str);
   }

   public static String convertToHexa32(String plainText) throws NoSuchAlgorithmException {
      String resultHexa32 = null;
      MessageDigest m = MessageDigest.getInstance("MD5");
      m.reset();
      m.update(plainText.getBytes());
      byte[] digest = m.digest();
      BigInteger bigInt = new BigInteger(1, digest);

      String hashtext;
      for(hashtext = bigInt.toString(16); hashtext.length() < 32; hashtext = "0" + hashtext) {
      }

      resultHexa32 = hashtext.toUpperCase();
      return resultHexa32;
   }

   public static File createDirectory(String dirPath) {
      File dir = new File(dirPath);
      if (!isDirectoryExist(dir)) {
         dir.mkdirs();
      }

      return dir;
   }

   public static boolean isDirectoryExist(File dir) {
      return dir.exists() && dir.isDirectory();
   }

   public static void loggedXflow(XFlowLogger xFlowLogger, String Status, String contentName, String content) {
      xFlowLogger.UpdateGlobalStatus(Status);
      xFlowLogger.AddConfiguration(contentName, content);
      xFlowLogger.SaveXFlowXML();
   }

   public static void loggedXflowGlobalStatus(XFlowLogger xFlowLogger, String Status, String content) {
      xFlowLogger.UpdateGlobalStatus(Status);
      xFlowLogger.AddGlobalStatusDetailInfo(content);
      xFlowLogger.SaveXFlowXML();
   }

   public static Properties getProperties(String filename, XFlowLogger xFlowLogger) {
      String inputFilePath = "";
      Properties properties = new Properties();

      try {
         inputFilePath = EDAT_DB_Analyser.objAnlayserConfig.getDecodedPropertiesPath() + File.separator + "config" + File.separator + filename;
         InputStream input = new FileInputStream(inputFilePath);
         properties.load(input);
         if (xFlowLogger != null) {
            loggedXflow(xFlowLogger, "OK", "ConfigFileName", inputFilePath);
         }
      } catch (Exception var5) {
         loggedXflowGlobalStatus(xFlowLogger, "KO", "Exception : " + filename + " file missing at " + inputFilePath);
         System.out.println("Property file " + filename + " missing at directory " + inputFilePath);
      }

      return properties;
   }

   public static void writeToCyclicObjectFile(String logstr) {
      try {
         PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(EDAT_DB_Analyser.objAnlayserConfig.getBaseDirectory() + File.separator + "CyclicData.txt", true)));
         writer.println(logstr);
         writer.close();
      } catch (Exception var2) {
         System.out.println("EDAT_AnalyserPropertyUtils ---- Error while print cyclic data in file. Error: " + var2);
      }

   }
}
