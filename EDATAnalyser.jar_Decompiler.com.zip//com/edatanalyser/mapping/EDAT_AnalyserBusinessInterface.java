package com.edatanalyser.mapping;

import com.edatxflowlogger.XFlowLogger;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.MapList;
import matrix.db.Context;
import matrix.util.StringList;

public interface EDAT_AnalyserBusinessInterface {
   StringList lstSkipObjects = new StringList();
   StringList lstHavingSpaceFilesNames = new StringList();
   StringList lstFilenameLenGT100Char = new StringList();
   StringList lstInvalidNames = new StringList();
   StringList lstMissingFilesNames = new StringList();
   StringList lstHavingMultipleFilesAttached = new StringList();

   String getRootQuery();

   String getLOTDateTimeWhereClause(EDAT_AnalyserConfigurationInterface var1, XFlowLogger var2);

   void fetchServerDataBased(Context var1, String var2, String var3, String var4, String var5, boolean var6, String var7) throws FrameworkException;

   StringBuffer getCadBasedWhereClause(String var1, String var2, boolean var3, String var4);

   boolean cleanDataCheck(String var1, String var2, String var3, String var4, String var5);

   MapList getRootObjectDetails(Context var1, StringList var2, String var3);
}
