package com.edatanalyser.mapping;

import java.io.IOException;
import java.util.List;

public interface EDAT_AnalyserConfigurationInterface {
   String getFullMode();

   void setFullMode(String var1);

   String getCADType();

   void setCADType(String var1);

   String getRecoveryMode();

   void setRecoveryMode(String var1);

   String getReleasedState();

   void setReleasedState(String var1);

   String getMaturity();

   void setMaturity(String var1);

   boolean isGrtThan15x();

   void setGrtThan15x(String var1);

   String getDecodedPropertiesPath();

   void setDecodedPropertiesPath() throws IOException;

   List<String> getLstImmediateTypes();

   void setLstImmediateTypes();

   List<String> getLstNonImmediateTypes();

   void setLstNonImmediateTypes();

   String getCloudMigration();

   void setCloudMigration(String var1);

   String getLotStartDateTime();

   void setLotStartDateTime(String var1);

   String getLotEndDateTime();

   void setLotEndDateTime(String var1);

   String getBaseDirectory();

   void setBaseDirectory(String var1);

   void validateDirectory(String var1) throws IOException;

   void setDashboard(String var1);

   String getDashboard();
}
